package Models;

public class Course {
}
