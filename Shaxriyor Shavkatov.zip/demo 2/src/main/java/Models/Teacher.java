package Models;

public class Teacher {
}
