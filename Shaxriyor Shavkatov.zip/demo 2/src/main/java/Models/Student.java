package Models;

public class Student {
}
