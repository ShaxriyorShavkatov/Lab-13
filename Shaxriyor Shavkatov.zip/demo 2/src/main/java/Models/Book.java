package Models;

public class Book {
}
